﻿using DAL;
using Entities;

namespace BL
{
    public class BookBL
    {
        BookDAL bDal = new BookDAL();
        public List <Book> getAllBook()
        {
            return bDal.getAllBook();
        }

        public bool AddBook(Book bk)
        {
            bool res = bDal.AddBook(bk);

            return res;
        }

        public bool Update(Book bk)
        {
            return bDal.Update(bk);
        }

        public Book? GetBook(int id)
        {
            return bDal.GetBook(id);
        }

        public Book? Delete(int id)
        {
            return bDal.Delete(id);
        }
    }
}