﻿using BL;
using Entities;
using Microsoft.AspNetCore.Mvc;

namespace BookManagementWeb.Controllers
{
    public class BookController : Controller
    {

        BookBL bbl = new BookBL();
        public IActionResult Index()
        {
            List <Book> blist = bbl.getAllBook();

            return View(blist);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Book bk)
        {
            bool res = bbl.AddBook(bk);

            if(res)
            {
                ViewData["msg"] = "Added Successfully.";

                return View("Success",bk);
            }

            return View();
        }

        [HttpGet]
        public IActionResult Update(int Id)
        {
            Book? bk = bbl.GetBook(Id);

            return View(bk);
        }

        [HttpPost]
        public IActionResult Update(Book bk)
        {
            bool res = bbl.Update(bk);

            if (res)
            {
                ViewData["msg"] = "Updated Successfully.";

                return View("Success", bk);
            }

            return View();
        }

        public IActionResult Delete(int Id)
        {
            Book bk = bbl.Delete(Id);
            if (bk != null)
            {
                ViewData["msg"] = "Deleted Successfully.";

                return View("Success", bk);
            }

            return View("Index");
        }
    }
}
