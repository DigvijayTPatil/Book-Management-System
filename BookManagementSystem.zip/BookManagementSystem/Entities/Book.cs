﻿namespace Entities
{
    public class Book
    {
        public int Id { get; set; }
        public string? Title { get; set; }    //? means nullable
        public string? Author { get; set; }
        public string? Publication { get; set; }
        public float? Price { get; set; }
        public char BookType { get; set; }
        public DateTime? Created { get; set; } = DateTime.Now; //default value for date
        public DateTime? Updated { get; set; } = DateTime.Now;

        public Book()  //default constructore
        {

        }

        //parameterised constructor
        public Book(int id, string? title, string? author, string? publication, float? price, char bookType, DateTime? created, DateTime? updated)
        {
            Id = id;
            Title = title;
            Author = author;
            Publication = publication;
            Price = price;
            BookType = bookType;
            Created = created;
            Updated = updated;
        }
    }
}