﻿using Entities;
using Repository;

namespace DAL
{
    public class BookDAL
    {
        
        public List <Book> getAllBook()
        {
            return BookRepository.AllBooks;
        }

        public bool AddBook(Book bk)
        {
            BookRepository.AllBooks.Add(bk);

            return true;
        }

       public bool Update(Book bk)
        {
            foreach (var book in BookRepository.AllBooks) 
            {
                if(book.Id == bk.Id)
                {
                    book.Title = bk.Title;
                    book.Author = bk.Author;
                    book.Publication = bk.Publication;
                    book.Price = bk.Price;
                    book.BookType = bk.BookType;
                    book.Updated = DateTime.Now;
                    return true;

                }
            }

            return false;
        }

        public Book? GetBook(int id)
        {
            Book? bk = BookRepository.AllBooks.Where(b=>b.Id == id).FirstOrDefault();
            return bk;
        }

        public Book? Delete(int id)
        {
            Book? bk = BookRepository.AllBooks.Where(b => b.Id == id).FirstOrDefault();

            if(bk != null)
            {
                BookRepository.AllBooks.Remove(bk);
            }

            return bk;
        }
    }
}