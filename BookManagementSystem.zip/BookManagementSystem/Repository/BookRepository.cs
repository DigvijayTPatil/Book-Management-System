﻿using Entities;

namespace Repository
{
    public static class BookRepository
    {
        public static List<Book> AllBooks = new List<Book>()
        { 
        
            new Book{Id=1, Title="ABC", Author="Digvijay", Publication="PQR", Price=100.2f, BookType='E'},
            new Book{Id=2, Title="DEF", Author="Digvi", Publication="RST", Price=120.2f, BookType='H'},
            new Book{Id=3, Title="GHI", Author="Jay", Publication="UVW", Price=130.2f, BookType='E'},
            new Book{Id=4, Title="JKL", Author="Dig", Publication="XYZ", Price=150.2f, BookType='E'},


        };
    }
}